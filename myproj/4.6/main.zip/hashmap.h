#ifdef _WIN32
    #ifdef HASHMAP_EXPORTS
        #define HASHMAP_API __declspec(dllexport)
    #else
        #define HASHMAP_API __declspec(dllimport)
    #endif
#else
    #define HASHMAP_API
#endif

#include <stdint.h>
#include <stdlib.h>

typedef const void *cpvoid;

typedef int (*EqualFunc)(cpvoid a, cpvoid b);

typedef uint32_t (*HashFunc)(cpvoid key);

typedef struct Node {
    int fl;
    cpvoid key;
    cpvoid value;
} Node;

typedef struct HashMap {
    EqualFunc eq;
    HashFunc hash;
    int size;
    Node *nodes;
} HashMap;

HASHMAP_API HM_Init(EqualFunc ef, HashFunc hf, int size);

HASHMAP_API void HM_Destroy(HashMap *self);

HASHMAP_API cpvoid HM_Get(const HashMap *self, cpvoid key);

HASHMAP_API void HM_Set(HashMap *self, cpvoid key, cpvoid value);